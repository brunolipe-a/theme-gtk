---
name: Documentation report
about: Use this template for documentation (install instructions, README) related issues
---

<!-- Verify first that your issue is not already reported -->

<!-- Please only use this template for documentation related issues -->

<!-- If possible complete *all* sections as described. Don't remove any section. -->

**Description of issue**

<!-- A clear description what needs changing, why should it be changed? How is it useful? -->
